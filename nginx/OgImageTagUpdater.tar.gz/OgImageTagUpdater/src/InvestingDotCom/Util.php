<?php
/**
 * Created by PhpStorm.
 * User: zach
 * Date: 7/28/14
 * Time: 5:24 PM
 */

namespace InvestingDotCom;


class Util {

    protected $pdo;

    protected $pdoOptions = array(
        \PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'",
        \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC
    );

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function getAllSqlAccessByLanguageId($languageId)
    {
        $query = 'SELECT `sql_ip`,`sql_user`,`sql_pass`, `sql_db` FROM `all_sql_access` WHERE lang_id = :langId and site_type="forex"';
        $stmt = $this->pdo->prepare($query);

        $stmt->bindParam(':langId' , $languageId, \PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if(!$row){
            throw new \Exception('getAllSqlAccessByLanguageId function with id '.$languageId . ' not found');
        }
        return $row;
    }

    public function getAllSqlAccessAsArray($domainId=null)
    {
        $returnArray = array();
        $query = 'SELECT `domain_ID`,`sql_ip`,`sql_user`,`sql_pass`, `sql_db` FROM `all_sql_access` WHERE site_type="forex"';
        if($domainId){
            $query.=' AND domain_ID = :domainId';
            $stmt = $this->pdo->prepare($query);
            $stmt->bindParam(':domainId', $domainId, \PDO::PARAM_INT);
        } else {
            $stmt = $this->pdo->prepare($query);
        }


        $stmt->execute();
        $resultSet = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if(!$resultSet){
            throw new \Exception('getAllSqlAccessByLanguageId function failed');
        }
        foreach($resultSet as $row )
        {
            $returnArray[$row['domain_ID']] = array(
                'domain_ID' => $row['domain_ID'],
                'sql_ip'=> $row['sql_ip'],
                'sql_user' => $row['sql_user'],
                'sql_pass' => $row['sql_pass'],
                'sql_db' => $row['sql_db']
            );
        }
        return $returnArray;
    }

    public function getSqlAccessByDomainId($domainId)
    {
        $returnArray = array();
        $query = 'SELECT `domain_ID`,`sql_ip`,`sql_user`,`sql_pass`, `sql_db` FROM `all_sql_access` WHERE site_type="forex"'
        .' AND domain_ID = :domainId'
        ;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute();
        $resultSet = $stmt->fetch(\PDO::FETCH_ASSOC);
        if(!$resultSet){
            throw new \Exception('getAllSqlAccessByLanguageId function failed');
        }
        foreach($resultSet as $row )
        {
            $returnArray[$row['domain_ID']] = array(
                'domain_ID' => $row['domain_ID'],
                'sql_ip'=> $row['sql_ip'],
                'sql_user' => $row['sql_user'],
                'sql_pass' => $row['sql_pass'],
                'sql_db' => $row['sql_db']
            );
        }
        return $returnArray;
    }
    public function getAllSqlWhereInQuery($query, $discriminatorField='discriminator', $domainId)
    {
        $allSqlAccessArray = $this->getAllSqlAccessAsArray($domainId);

        foreach ($allSqlAccessArray as $domainId => $sqlAccessArray){
            $dbName = $sqlAccessArray['sql_db'];
            $dbHost = $sqlAccessArray['sql_ip'];
            $dbUser = $sqlAccessArray['sql_user'];
            $dbPassword = $sqlAccessArray['sql_pass'];
            $dsn = 'mysql:dbname=' . $dbName . ';host=' . $dbHost;
            $this->pdo = new \PDO($dsn, $dbUser, $dbPassword, $this->pdoOptions);
            $stmt = $this->pdo->prepare($query);
            $stmt->execute();
            $resultSet = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$resultSet || ! intval($resultSet[$discriminatorField]) ) {
                unset ($allSqlAccessArray[$domainId]);
            }
        }
        return $allSqlAccessArray;
    }

    public function getAllDbsForOgTagUpdate($domainId=false)
    {

        $query = "
            SELECT count(*) as count
            FROM   `news_reuters` nr
            INNER JOIN `news_provider` np on np.news_provider_ID = nr.news_provider_ID and np.news_provider_name = 'Reuters'
            WHERE org_file LIKE  'KBN%' AND ISNULL( extra_images ) AND BODY LIKE  '%LYNX%'
        ";
        return $this->getAllSqlWhereInQuery($query, 'count', $domainId);

    }
} 