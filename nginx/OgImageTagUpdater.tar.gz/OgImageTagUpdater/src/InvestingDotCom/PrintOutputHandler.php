<?php

namespace InvestingDotCom;

class PrintOutputHandler implements \SplObserver
{
    protected $logger;
    public function __construct()
    {
    }

    /**
     * (PHP 5 &gt;= 5.1.0)<br/>
     * Receive update from subject
     * @link http://php.net/manual/en/splobserver.update.php
     * @param \InvestingDotCom\SplSubject|\SplSubject $subject <p>
     * The <b>SplSubject</b> notifying the observer of an update.
     * </p>
     * @return void
     */
    public function update(\SplSubject $subject)
    {
        foreach ($subject->getLoggedEvents() as $key => $arrMessage){
            $level = $arrMessage['level'];
            $message = $arrMessage['message'];
            try{
                print('<br/>Level: ' .$level . ' Message: '.$message);
            } catch (\Exception $e) {
                throw $e;
            }
        }
    }
}