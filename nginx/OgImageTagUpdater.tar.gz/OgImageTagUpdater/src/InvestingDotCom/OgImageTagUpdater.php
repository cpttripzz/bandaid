<?php
/**
 * Created by PhpStorm.
 * User: zach
 * Date: 7/24/14
 * Time: 5:53 PM
 */

namespace InvestingDotCom;

use SplObserver;

class OgImageTagUpdater implements \SplSubject
{

    protected $pdo;
    protected $isDryRun;
    protected $logErrors;
    protected $idTag = 'TRKD';
    protected $extraImagesDelimiter = '||'; //TRKD||LYNXMPEA6S09M
    const MAX_LIMIT = 10;


    /**
     * An array of SplObserver objects
     * to notify of Exceptions.
     * @var array
     */
    protected $observers = array();

    /**
     * An array that holds log level as key and
     * message as value
     * @var array
     */
    protected $arrLog = array();

    public function __construct($pdo, $isDryRun = true, $logErrors = false)
    {
        $this->pdo = $pdo;
        $this->isDryRun = $isDryRun;
        $this->logErrors = $logErrors;
    }


    protected function pushLogMessage($level, $message, $notify = true, $clearMessagesAfterNotify = false)
    {
        $arrLogMessage = array('level' => $level, 'message' => $message);
        array_push($this->arrLog, $arrLogMessage);
        if ($notify) {
            $this->notify();
            if ($clearMessagesAfterNotify) {
                $this->arrLog = array();
            }
        }

    }

    public function update()
    {
        $arrUpdates = array();
        $iterationCounter = 0;
        $countFields = ' SELECT count(*) as count ';
        $selectFields = ' SELECT News_ID as id, BODY as body';
        $queryBody = "
            FROM   `news_reuters` nr
            INNER JOIN `news_provider` np on np.news_provider_ID = nr.news_provider_ID and np.news_provider_name = 'Reuters'
            WHERE org_file LIKE  'KBN%' AND ISNULL( extra_images ) AND BODY LIKE  '%LYNX%'
        ";
        $stmt = $this->pdo->prepare($countFields . $queryBody);
        $stmt->execute();
        $resultSet = $stmt->fetch(\PDO::FETCH_ASSOC);
        $count = intval($resultSet['count']);
        while ($this::MAX_LIMIT * $iterationCounter < $count) {
            $limit = ' LIMIT ' . $this::MAX_LIMIT ;
            $query = $selectFields . $queryBody . ' ORDER BY id ' .$limit ;
            $this->pushLogMessage('info', $query, false);
            $stmt = $this->pdo->prepare($query);
            $stmt->execute();
            $resultSet = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            foreach ($resultSet as $row) {
                $arrImgs = array();
                $dom = new \DOMDocument();
                @$dom->loadHTML($row['body']); //yes bad practice, bad input as well
                $images = $dom->getElementsByTagName('img');
                foreach ($images as $image) {
                    $src = $image->getAttribute('src');
                    $base = basename($src);
                    $arrParts = explode('_', $base);
                    if (isset($arrParts[0])) {
                        if(strpos($arrParts[0], 'LYNX') !== false){
                            $arrImgs[] = $this->idTag . $this->extraImagesDelimiter . $arrParts[0];
                        }
                    } else {
                        continue;
                    }
                }
                if ($arrImgs) {
                    $strExtraImages = implode(',', $arrImgs);
                    $updateQuery = 'UPDATE news_reuters SET extra_images = "' . $strExtraImages . '" WHERE News_ID = ' . $row['id'];
                    $this->pushLogMessage('info', $updateQuery, false);
                    $updateQuery = 'UPDATE news_reuters SET extra_images = :extraImages' .
                        ' WHERE News_ID = :newsId ';
                    $stmt = $this->pdo->prepare($updateQuery);
                    $stmt->bindParam(':extraImages', $strExtraImages, \PDO::PARAM_STR);
                    $stmt->bindParam(':newsId', $row['id'], \PDO::PARAM_INT);

                    if (!$this->isDryRun) {
                        $stmt->execute();
                    }
                }

            }
            $this->pushLogMessage('info', 'finished batch offset ' . $this::MAX_LIMIT * $iterationCounter, true, true);

            $iterationCounter++;
        }

    }


    /**
     * (PHP 5 &gt;= 5.1.0)<br/>
     * Attach an SplObserver
     * @link http://php.net/manual/en/splsubject.attach.php
     * @param SplObserver $observer <p>
     * The <b>SplObserver</b> to attach.
     * </p>
     * @return void
     */
    public function attach(SplObserver $observer)
    {
        $id = spl_object_hash($observer);
        $this->observers[$id] = $observer;
    }

    /**
     * (PHP 5 &gt;= 5.1.0)<br/>
     * Detach an observer
     * @link http://php.net/manual/en/splsubject.detach.php
     * @param SplObserver $observer <p>
     * The <b>SplObserver</b> to detach.
     * </p>
     * @return void
     */
    public function detach(SplObserver $observer)
    {
        $id = spl_object_hash($observer);
        unset($this->observers[$id]);
    }

    /**
     * (PHP 5 &gt;= 5.1.0)<br/>
     * Notify an observer
     * @link http://php.net/manual/en/splsubject.notify.php
     * @return void
     */
    public function notify()
    {
        foreach ($this->observers as $observer) {
            $observer->update($this);
        }
    }

    public function getLoggedEvents()
    {
        return $this->arrLog;
    }
}