<?php
namespace InvestingDotCom;

use Monolog\Handler\StreamHandler;

class ConsoleController
{

    protected $logger;
    protected $logErrors;
    protected $printOutput;
    protected $benchmark;


    public function __construct($logPath, $logger)
    {
        $this->logger = $logger;
        $this->logger->pushHandler(new StreamHandler($logPath));
    }

    protected function pushLogMessage($level, $message)
    {
        if ($this->logErrors) {
            $this->logger->$level($message);
        }
    }

    public function run()
    {
        $this->benchmark = !empty($_REQUEST['benchmark']) ? filter_var($_REQUEST['benchmark'], FILTER_VALIDATE_BOOLEAN) : false;
        $startTime = microtime(true);
        header("content-type: text/html; charset=UTF-8");

        $this->logErrors = !empty($_REQUEST['log-errors']) ? filter_var($_REQUEST['log-errors'], FILTER_VALIDATE_BOOLEAN) : false;
        $this->printOutput = !empty($_REQUEST['print-output']) ? filter_var($_REQUEST['print-output'], FILTER_VALIDATE_BOOLEAN) : false;
        $dryRun = empty($_REQUEST['dry-run']) ? true : filter_var($_REQUEST['dry-run'], FILTER_VALIDATE_BOOLEAN);
        $domainId = empty($_REQUEST['domain-id']) ? false : intval($_REQUEST['domain-id']);

        $options = array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'",
            \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC
        );
        $dbName = 'forexpros_admin';
        $dsn = 'mysql:dbname=' . $dbName . ';host=' . _dbHost;
        $pdo = new \PDO($dsn, _dbUser, _dbPassword, $options);
        $util = new Util($pdo);
        try {
            $allSqlAccessDetailsForOgTagUpdate = $util->getAllDbsForOgTagUpdate($domainId);
        } catch (\Exception $e) {
            throw $e;
        }
        unset($util);
//        die(var_dump($allSqlAccessDetailsForOgTagUpdate));
        foreach ($allSqlAccessDetailsForOgTagUpdate as $domainId => $allSqlAccessDetails) {
            $dbName = $allSqlAccessDetails['sql_db'];
            $dbHost = $allSqlAccessDetails['sql_ip'];
            $dbUser = $allSqlAccessDetails['sql_user'];
            $dbPassword = $allSqlAccessDetails['sql_pass'];
            $dsn = 'mysql:dbname=' . $dbName . ';host=' . $dbHost;
            $pdo = new \PDO($dsn, $dbUser, $dbPassword, $options);
            $this->pushLogMessage('info', 'Using db: ' . $dbName . ' dbHost: ' . $dbHost . ' dbUser: ' . $dbUser);

            $ogImageTagUpdater = new OgImageTagUpdater($pdo, $dryRun, $this->logErrors);
            $logHandler = new LoggerHandler($this->logger);

            if ($this->printOutput) {
                $printOutputHandler = new PrintOutputHandler();
                $ogImageTagUpdater->attach($printOutputHandler);
            }
            $ogImageTagUpdater->attach($logHandler);

            $ogImageTagUpdater->update();

        }
        $endTime = microtime(true);
        if ($this->benchmark) {
            $this->pushLogMessage('info', 'time of script execution: ' . ($endTime - $startTime));
        }
    }
}