<?php
require './vendor/autoload.php';
require '../includes/config.php';

$logPath = 'logs/OgImageTagUpdater.log';
$logger = new Monolog\Logger('OgImageTagUpdater');

$consoleController = new InvestingDotCom\ConsoleController($logPath, $logger);
try {
    $consoleController->run();
} catch (Exception $e) {
    print $e->getMessage();
}
