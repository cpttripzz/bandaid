<?php
require_once('widget/jqGrid.php');
$webPath = 'system/webmaster_tools_domain_admin';
$grid = new jqGrid(
    'gridBlocked',
    $webPath . '/ajax.php?oper=fetch',
    'pagerBlocked',
    0, 'host_ID', 'DESC'
);

$grid->setEditUrl($webPath . '/ajax.php?oper=edit');
$beforeSaveCell = '
        function(rowid,celname,value,iRow,iCol) {
           $( "#dialog-confirm" ).dialog({
              resizable: false,
              height:140,
              modal: true,
              buttons: {
                "Change status": function() {
                  $.ajax({
                  type: "POST",
                  url: "' . $webPath . '/ajax.php?oper=edit",
                  data: { id: rowid, value: value}
                })
                 $( this ).dialog( "close" );
                },
                Cancel: function() {
                  $( this ).dialog( "close" );
                }
              }
            });
        }
    ';

$grid->setBeforeSaveCell($beforeSaveCell);
?>

<?php $grid->render(); ?>
<div style="visibility: hidden">
    <form id="frm_upload_csv" name="frm_upload_csv" action="<?php echo $webPath; ?>/ajax.php?oper=upload"
          method="post" enctype="multipart/form-data">
        <input type="file" id="upload_csv" name="upload_csv">
    </form>
</div>
<script type="application/javascript">
    $(function () {
        $('#frm_upload_csv')
            .submit(function (e) {
                var action = $('#frm_upload_csv').attr('action');
                var method = $('#frm_upload_csv').attr('method');
                $.ajax({
                    url: action,
                    type: method,
                    data: new FormData(this),
                    processData: false,
                    contentType: false
                }).done(function (data) {
                    if (typeof data != 'undefined') {
                        data = $.parseJSON(data);

                        if (data.errors) {
                            $('#span-icon').addClass('ui-icon-alert');
                        } else {
                            $('#span-icon').addClass('ui-icon-circle-check');
                        }
                        $('#dialog-message').dialog({
                            modal: true,
                            open: function() {
                                $('#p-message').append(data.message)
                                    .css('visibility','visible');
                            },
                            buttons: {
                                Ok: function() {
                                    $( this ).dialog( "close" );
                                }
                            }
                        });
                        $("#gridBlocked").trigger("reloadGrid");
                    }

                });

                e.preventDefault();
            });

        $("#upload_csv").change(function (e) {
            $('#frm_upload_csv').submit();
        });

        $.fn.center = function () {
            this.css("position", "absolute");
            this.css("top", ( $(window).height() - this.height() ) / 2 + $(window).scrollTop() + "px");
            this.css("left", ( $(window).width() - this.width() ) / 2 + $(window).scrollLeft() + "px");
            return this;
        }
    });
</script>