<?php
try {

    function isValidDomain($domain_name)
    {
        return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain_name) //valid chars check
            && preg_match("/^.{1,253}$/", $domain_name) //overall length check
            && preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain_name)); //length of each label
    }

    $operation = $_REQUEST['oper'];

    $dbHost = '';
    $dbUser = '';
    $dbPassword = '';
    $dbName = '';
    $statuses = array('block', 'nofollow', 'paid');
    $options = array(
        \PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'",
        \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_ASSOC
    );

    $dsn = 'mysql:dbname=' . $dbName . ';host=' . $dbHost;
    $pdo = new \PDO($dsn, $dbUser, $dbPassword, $options);
    $tableName = 'ex_tools_hosts_new';
    switch ($_SERVER['REQUEST_METHOD']) {

        case "GET" :
            $page = !empty($_GET['page']) ? $_GET['page'] : 0; // get the requested page
            $limit = !empty($_GET['rows']) ? intval($_GET['rows']) : 10; // get how many rows we want to have into the grid
            $sidx = !empty($_GET['sidx']) ? $_GET['sidx'] : 'id'; // get index row - i.e. user click to sort
            $sord = $_GET['sord']; // get the direction
            $columns = array(
                'host_ID' => \PDO::PARAM_INT, 'host_name' => \PDO::PARAM_STR, 'added_time' => \PDO::PARAM_STR, 'google_pagerank' => \PDO::PARAM_INT, 'domain_status' => \PDO::PARAM_STR
            );
            $directions = array('asc', 'desc');

            $isSearch = (!empty($_GET['_search'])) ? $_GET['_search'] : false;
            $domainStatus = (!empty($_GET['domain_status'])) ? $_GET['domain_status'] : null;
            if (!in_array($sord, $directions)) {
                $sord = 'DESC';
            }
            if (!in_array($sidx, array_keys($columns))) {
                $sidx = reset(array_keys($columns));
            }
            if (!in_array($domainStatus, $statuses)) {
                unset($_GET['domain_status']);
            }
            $columnsToUseLIkeCondition = array('host_name');
            $selectColumns = 'SELECT ' . implode(',', array_keys($columns));
            $selectCount = 'SELECT COUNT(*) as count ';
            $from = ' FROM ' . $tableName;
            $where = ' WHERE 1=1';
            $boundParams = array();
            foreach ($columns as $column => $type) {
                if (isset($_GET[$column])) {
                    if (in_array($column,$columnsToUseLIkeCondition ) ) {
                        $value = '%' .$_GET[$column] . '%';
                        $condition = ' LIKE ';
                    } else {
                        $value = $_GET[$column];
                        $condition = ' = ';
                    }
                    $boundParams[$column] = $value;
                    $where .= ' AND ' . $column . $condition .' :' .$column;
                }
            }

            $stmt = $pdo->prepare($selectCount . $from . $where);

            foreach ($boundParams as $key => &$value) {
                $stmt->bindParam(':' . $key, $value, $columns[$key]);
            }
            $stmt->execute();

            $resultSet = $stmt->fetch(\PDO::FETCH_ASSOC);
            $count = $resultSet['count'];
            if ($count > 0) {
                $totalPages = ceil($count / $limit);
            } else {
                $totalPages = 0;
            }
            if ($page > $totalPages) {
                $page = $totalPages;
            }
            $start = 0;
            if ($page > 0) {
                $start = $limit * $page - $limit;
            }

            $order = " ORDER BY $sidx $sord LIMIT $start, $limit";
            $stmt = $pdo->prepare($selectColumns . $from . $where . $order);
            foreach ($boundParams as $key => &$value) {
                $stmt->bindParam(':' . $key, $value, $columns[$key]);
            }
            $stmt->execute();
            $resultSet = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $response = array();
            $response['page'] = $page;
            $response['total'] = $totalPages;
            $response['records'] = $count;
            $response['rows'] = array();
            foreach ($resultSet as $row) {
                $arrCell = array();
                foreach (array_keys($columns) as $column) {
                    $arrCell[] = $row[$column];
                }
                $returnArray = array(
                    'id' => $row['host_ID'],
                    'cell' => $arrCell
                );
                $response['rows'][] = $returnArray;
            }

            echo json_encode($response);
            break;
        case "POST":
            switch ($operation) {
                case 'edit':
                    if (empty($_POST['id'])) {
                        return json_encode(array('success' => false, 'msg' => 'invalid parmeters sent'));
                    }
                    $domainStatus = (!empty($_POST['domain_status'])) ? $_POST['domain_status'] : null;
                    if (!in_array($domainStatus, $statuses)) {
                        $domainStatus = $statuses[0];
                    }
                    $query = 'UPDATE ' . $tableName . ' SET domain_status = :domain_status WHERE host_ID = :host_ID';
                    $stmt = $pdo->prepare($query);
                    $stmt->bindParam(':domain_status', $domainStatus, \PDO::PARAM_STR);
                    $stmt->bindParam(':host_ID', $_POST['id'], \PDO::PARAM_INT);
                    $stmt->execute();
                    return json_encode(array('success' => true, 'msg' => 'row updated'));
                    break;
                case 'del':
                    if (empty($_POST['id'])) {
                        return json_encode(array('success' => false, 'msg' => 'invalid parmeters sent'));
                    }
                    $values = explode(',', $_POST['id']);
                    $inParam = implode(',', array_fill(1, count($values), '?'));
                    $query = 'DELETE FROM ' . $tableName . ' WHERE host_ID IN (' . $inParam . ')';
                    $stmt = $pdo->prepare($query);
                    $counter = 0;
                    foreach ($values as &$value) {
                        $counter++;
                        $stmt->bindParam($counter, $value, \PDO::PARAM_INT);
                    }
                    $stmt->execute();
                    return json_encode(array('success' => true, 'msg' => 'rows deleted'));
                    break;
                case 'upload':
                    $returnArray = array();
                    $invalid = false;
                    $validIds=0;
                    if ($_FILES ['upload_csv'] ['name'] != '') {
                        $ERROR_INVALID_DOMAIN = 1;
                        $ERROR_DOMAIN_EXISTS = 2;
                        $arrFailedIds = array();
                        $arrFailedIds[$ERROR_DOMAIN_EXISTS] = array();
                        $arrFailedIds[$ERROR_INVALID_DOMAIN] = array();
                        $message = '';
                        $extension = strtolower(substr($_FILES ['upload_csv'] ['name'], -3, 3));
                        if ($extension != 'csv') {
                            $message = 'Not a valid extension';
                            $invalid = true;
                        }
                        if (!$invalid) {
                            $csv = array_map('str_getcsv', file($_FILES ['upload_csv'] ['tmp_name']));
                            foreach ($csv as $key => $row) {
                                $domain = trim($row[0]);
                                if (!isValidDomain($domain)) {
                                    $arrFailedIds[$ERROR_INVALID_DOMAIN][] = $domain;
                                    $invalid = true;
                                    continue;
                                }
                                $domainStatus = trim($row[1]);
                                if (!in_array($domainStatus, $statuses)) {
                                    $domainStatus = $statuses[0];
                                }
                                $query = 'SELECT COUNT(*) as count FROM ' . $tableName . ' WHERE host_name = :host_name';
                                $stmt = $pdo->prepare($query);
                                $stmt->bindParam(':host_name', $domain, \PDO::PARAM_STR);
                                $stmt->execute();
                                $resultSet = $stmt->fetchAll(\PDO::FETCH_ASSOC);
                                if (!empty($resultSet[0]['count'])) {
                                    $arrFailedIds[$ERROR_DOMAIN_EXISTS][] = $domain;
                                    $invalid = true;
                                    continue;
                                }
                                $query = 'INSERT INTO ' . $tableName . '( domain_status,  added_time, host_name)' .
                                    ' VALUES ("' . $domainStatus . '", NOW(), "' . $domain . '")';
                                $validIds ++;
                                $pdo->query($query);
                            }
                        }
                        if ($invalid) {
                            $message = 'Errors found: ' . $message . "\n<br/> ";
                            if (!empty($arrFailedIds[$ERROR_INVALID_DOMAIN])) {
                                $message .= 'The following '.count($arrFailedIds[$ERROR_INVALID_DOMAIN]).' hosts were invalid:' . implode(', ', $arrFailedIds[$ERROR_INVALID_DOMAIN]) ."\n<br/> ";
                            }
                            if (!empty($arrFailedIds[$ERROR_DOMAIN_EXISTS])) {
                                $message .= 'The following '.count($arrFailedIds[$ERROR_DOMAIN_EXISTS]).' hosts were already found in the database:' . implode(', ', $arrFailedIds[$ERROR_DOMAIN_EXISTS]);
                            }
                        }

                    } else {
                        $invalid = true;
                        $message .='No file submitted';
                    }
                    if ($validIds) {
                        $message .= "\n<br/>" .$validIds . ' hosts were successfully added to the database';
                    }

                    $returnArray ['errors'] = $invalid;
                    $returnArray ['message'] = $message;
                    echo  (json_encode($returnArray));
                    break;
            }
            break;

    }
} catch (\Exception $e) {
    echo($e->getMessage());
}