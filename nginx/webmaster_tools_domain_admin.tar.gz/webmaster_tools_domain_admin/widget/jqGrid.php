<?php

class jqGrid
{
    protected $jqueryRef = '$';
    protected $id;
    protected $url;
    protected $datatype = 'json';
    protected $colNames = array('id', 'Host', 'Date', 'Page Rank', 'Block Status');

//        '["id","Host", "Date", "Page Rank"]';
    protected $colModel = array(
        array('name' => 'host_ID', 'index' => 'host_ID', 'width' => '50'),
        array('name' => 'host_name', 'index' => 'host_name', 'width' => '120'),
        array('name' => 'added_time', 'index' => 'added_time', 'width' => '75'),
        array('name' => 'google_pagerank', 'index' => 'google_pagerank', 'width' => '50'),
        array('name' => 'domain_status', 'index' => 'domain_status', 'width' => '75', 'align' => "center", 'search' => true, 'stype' => "select",
            'editable' => true, 'edittype' => "select", 'formatter' => 'select',
            'editoptions' => array(
                'value' => array('block' => 'Blacklisted', 'nofollow' => 'Blocked until nofollow', 'paid' => 'Paid Customer')
            ),
            'searchoptions' => array(
                'value' => array('all'=>'All','block' => 'Blacklisted', 'nofollow' => 'Blocked until nofollow', 'paid' => 'Paid Customer'),
                'defaultValue' => 'all'
            )
        )
    );

    /**
     * @param mixed $caption
     */
    public function setCaption($caption)
    {
        $this->caption = $caption;
    }

    /**
     * @return mixed
     */
    public function getCaption()
    {
        return $this->caption;
    }

    /**
     * @param array|null $colModel
     */
    public function setColModel($colModel)
    {
        $this->colModel = $colModel;
    }

    /**
     * @return array|null
     */
    public function getColModel()
    {
        return $this->colModel;
    }

    /**
     * @param array|null $colNames
     */
    public function setColNames($colNames)
    {
        $this->colNames = $colNames;
    }

    /**
     * @return array|null
     */
    public function getColNames()
    {
        return $this->colNames;
    }

    /**
     * @param string $datatype
     */
    public function setDatatype($datatype)
    {
        $this->datatype = $datatype;
    }

    /**
     * @return string
     */
    public function getDatatype()
    {
        return $this->datatype;
    }

    /**
     * @param mixed $editUrl
     */
    public function setEditUrl($editUrl)
    {
        $this->editUrl = $editUrl;
    }

    /**
     * @return mixed
     */
    public function getEditUrl()
    {
        return $this->editUrl;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $jqueryRef
     */
    public function setJqueryRef($jqueryRef)
    {
        $this->jqueryRef = $jqueryRef;
    }

    /**
     * @return string
     */
    public function getJqueryRef()
    {
        return $this->jqueryRef;
    }

    /**
     * @param mixed $onSelectRow
     */
    public function setBeforeSaveCell($onSelectRow)
    {
        $this->beforeSaveCell = $onSelectRow;
    }

    /**
     * @return mixed
     */
    public function getBeforeSaveCell()
    {
        return $this->beforeSaveCell;
    }

    /**
     * @param mixed $pager
     */
    public function setPager($pager)
    {
        $this->pager = $pager;
    }

    /**
     * @return mixed
     */
    public function getPager()
    {
        return $this->pager;
    }

    /**
     * @param array $rowList
     */
    public function setRowList($rowList)
    {
        $this->rowList = $rowList;
    }

    /**
     * @return array
     */
    public function getRowList()
    {
        return $this->rowList;
    }

    /**
     * @param mixed $rowNum
     */
    public function setRowNum($rowNum)
    {
        $this->rowNum = $rowNum;
    }

    /**
     * @return mixed
     */
    public function getRowNum()
    {
        return $this->rowNum;
    }

    /**
     * @param mixed $sortName
     */
    public function setSortName($sortName)
    {
        $this->sortName = $sortName;
    }

    /**
     * @return mixed
     */
    public function getSortName()
    {
        return $this->sortName;
    }

    /**
     * @param mixed $sortOrder
     */
    public function setSortOrder($sortOrder)
    {
        $this->sortOrder = $sortOrder;
    }

    /**
     * @return mixed
     */
    public function getSortOrder()
    {
        return $this->sortOrder;
    }

    /**
     * @param mixed $url
     */
    public function setUrl($url)
    {
        $this->url = $url;
    }

    /**
     * @return mixed
     */
    public function getUrl()
    {
        return $this->url;
    }

    protected $editUrl;
    protected $beforeSaveCell;
    protected $rowNum;
    protected $rowList = array(10, 25, 100);
    protected $pager;
    protected $sortName;
    protected $sortOrder;
    protected $caption;

    public function __construct($id, $url, $pager, $rowNum, $sortName, $sortOrder, $colNames = null, $colModel = null)
    {
        $this->id = $id;
        $this->url = $url;
        $this->pager = $pager;
        $this->rowNum = $rowNum;
        $this->sortName = $sortName;
        $this->sortOrder = $sortOrder;
        if (!empty($colNames)) {
            $this->colNames = $colNames;
        }
        if (!empty($colModel)) {
            $this->colModel = $colModel;
        }
    }

    public function render()
    {
        echo '<table id="' . $this->id . '"></table> ' . "\n" .
            '<div id="' . $this->pager . '" style="height:100%" ></div>' . "\n";
        $strOut =
            "<script type='application/javascript'>\n" .
            $this->jqueryRef . '("#' . $this->id . '").jqGrid({' . "\n" .
            "url: '$this->url', \n" .
            "datatype: '$this->datatype', \n" .
            "colNames: " . json_encode($this->colNames) . ", \n" .
            "colModel: " . json_encode($this->colModel) . ", \n" .
            "rowNum: 10, \n" .
            "rowList: " . json_encode($this->rowList) . ", \n" .
            "pager: '#$this->pager', \n" .
            "sortname: '$this->sortName',\n" .
            "viewrecords: true, \n" .
            "altRows: true, \n" .
            "multiselect: true, \n" .
            "autowidth: true, \n" .
            "height: 'auto', \n" .
            "sortorder: '$this->sortOrder', \n" .
            "caption: '$this->caption', \n";

        $strOut .= "editurl: '$this->editUrl', \n";
        $strOut .= "cellurl: '$this->editUrl', \n";
        $strOut .= "cellEdit: true, \n";
        $strOut .= "cellsubmit: 'remote', \n";
        $strOut .= "beforeSaveCell: $this->beforeSaveCell, \n";

        $strOut .= '});' . "\n" . "$this->jqueryRef ('#$this->id').jqGrid('filterToolbar',{searchOperators : true}); \n";

        $strOut .= "$this->jqueryRef ('#$this->id').jqGrid('inlineNav','#$this->pager'); \n";
        $strOut .= "$this->jqueryRef ('#$this->id').jqGrid('navGrid','#$this->pager',{edit:false,add:false,del:true},{},{},
                    {
                        afterShowForm: function(form) {
                                        console.log(form);
                                        form.closest('div.ui-jqdialog').center();
                                    }
                    }
                    ) \n";
        $strOut .= '.navButtonAdd("#'.$this->pager.'",{
                       caption:"Upload CSV File",
                       buttonicon:"ui-icon-plusthick",
                       onClickButton: function(){
                            $(\'input[type="file"]\').click();
                        },
                       position:"last"
                    }); ' ."\n";


        $strOut .=
            '</script>' . "\n" .
            '<div id="dialog-confirm" title="Change Block Status?"  style="visibility: hidden;">
                <p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>Change status of domain?</p>
            </div>'.
            '<div id="dialog-message" title="Upload status"  style="visibility: hidden;">
                <p id="p-message"><span id="span-icon" class="ui-icon" style="float:left; margin:0 7px 20px 0;"></span></p>
            </div>';
        echo $strOut;
    }

}